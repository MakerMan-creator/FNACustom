// MonoGame - Copyright (C) The MonoGame Team
// This file is subject to the terms and conditions defined in
// file 'LICENSE.txt', which is part of this source code package.

using System;
using VNEEngine;
using System.Collections.Generic;

namespace Microsoft.Xna.Framework
{
    public class GameComponent : IGameComponent, IUpdateable, IComparable<GameComponent>, IDisposable
    {
        bool _enabled = true;
        int _updateOrder;

        public Game Game { get; private set; }

		public Transform transform
		{
			get; protected set;
		}

		public GameObject gameObject
        {
            get; protected set;
        }

        public List<GameComponent> componentList
        {
            get;
            protected set;
        }

        public bool Enabled
        {
            get { return _enabled; }
            set
            {
                if (_enabled != value)
                {
                    _enabled = value;
                    if (this.EnabledChanged != null)
                        this.EnabledChanged(this, EventArgs.Empty);
                    OnEnabledChanged(this, null);
                }
            }
        }

        public int UpdateOrder
        {
            get { return _updateOrder; }
            set
            {
                if (_updateOrder != value)
                {
                    _updateOrder = value;
                    if (this.UpdateOrderChanged != null)
                        this.UpdateOrderChanged(this, EventArgs.Empty);
                    OnUpdateOrderChanged(this, null);
                }
            }
        }

		public event EventHandler<EventArgs> EnabledChanged;
        public event EventHandler<EventArgs> UpdateOrderChanged;

        public GameComponent(Game game)
        {
            this.Game = game;
        }

		public GameComponent(GameObject o, Game game)
        {
			this.gameObject = o;
			this.transform = gameObject.transform;
			this.Game = game;
        }

        ~GameComponent()
        {
            Dispose(false);
        }

        public virtual void Initialize() { }

        public virtual void Update(GameTime gameTime) { }

        protected virtual void OnUpdateOrderChanged(object sender, EventArgs args) { }

        protected virtual void OnEnabledChanged(object sender, EventArgs args) { }

        /// <summary>
        /// Shuts down the component.
        /// </summary>
        public virtual void Dispose(bool disposing) { }
        
        /// <summary>
        /// Shuts down the component.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
		/// <summary>
		/// This will only be used inside of this library.
		/// I think it's self-explanatory.
		/// </summary>
		/// <param name="o"></param>
		internal void SetGameObject(GameObject o)
        {
			this.gameObject = o;
        }

		/// <summary>
		/// This will only be used inside of this library
		/// I think it's self-explanatory.
		/// </summary>
		/// <param name="t"></param>
		internal void SetTransform(Transform t)
		{
			this.transform = t;
		}

		public T BaseGetComponent<T>() where T : GameComponent
        {
			return gameObject.BaseGetComponent<T>();
        }

        public void AddGameObject(GameObject o)
        {
            if ((this.gameObject == null) && (o != null))
            {
                this.gameObject = o;
            }
        }

        #region IComparable<GameComponent> Members
        // TODO: Should be removed, as it is not part of XNA 4.0
        public int CompareTo(GameComponent other)
        {
            return other.UpdateOrder - this.UpdateOrder;
        }

		#endregion

		#region ComponentMethods

		public void AddComponent(GameComponent component)
		{
			gameObject.AddComponent(component);
		}

		public void AddComponent<T>() where T : GameComponent
        {
			gameObject.AddComponent<T>();
        }

		public void AddComponents(List<GameComponent> components)
		{
			foreach (var component in components)
			{
				this.AddComponent(component);
			}
		}

		public List<T> GetComponents<T>() where T : GameComponent
		{
			return gameObject.GetComponents<T>();
		}

		public T[] GetComponentsArray<T>() where T : GameComponent
		{
			return gameObject.GetComponentsArray<T>();
		}

		public void AddComponents(GameComponent[] components)
		{
			foreach (var component in components)
			{
				this.AddComponent(component);
			}
		}

		public T GetComponent<T>() where T : GameComponent
		{
			// TODO: Add functionality
			return gameObject.GetComponent<T>();
		}

		public void RemoveComponent<T>() where T : GameComponent
		{
			gameObject.RemoveComponent<T>();
		}

		public void RemoveComponents<T>() where T : GameComponent
		{
			gameObject.RemoveComponents<T>();
		}

		#endregion
	}
}
