using System.Reflection;
using System.Runtime.CompilerServices;
[assembly: AssemblyVersion("4.0.0.0")]
[assembly: TypeForwardedToAttribute(typeof(Microsoft.Xna.Framework.Media.VideoSoundtrackType))]
[assembly: TypeForwardedToAttribute(typeof(Microsoft.Xna.Framework.Media.Video))]
[assembly: TypeForwardedToAttribute(typeof(Microsoft.Xna.Framework.Media.VideoPlayer))]