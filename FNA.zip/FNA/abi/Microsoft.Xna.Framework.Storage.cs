using System.Reflection;
using System.Runtime.CompilerServices;
[assembly: AssemblyVersion("4.0.0.0")]
[assembly: TypeForwardedToAttribute(typeof(Microsoft.Xna.Framework.Storage.StorageDevice))]
[assembly: TypeForwardedToAttribute(typeof(Microsoft.Xna.Framework.Storage.StorageContainer))]
[assembly: TypeForwardedToAttribute(typeof(Microsoft.Xna.Framework.Storage.StorageDeviceNotConnectedException))]