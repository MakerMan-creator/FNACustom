#!/bin/bash

msbuild /p:Configuration=Release SDL2-CS.csproj
